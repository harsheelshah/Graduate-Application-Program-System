package gapp.model.dao;

import gapp.model.GappAdditional;


import gapp.model.GappProgram;

import java.util.List;

public interface AdditionalDao {

	List<GappAdditional> getGappAdditional();
	
	 GappAdditional getAdditionalId(Integer id);
	 
	 GappAdditional remove(GappAdditional a1);
}
