package gapp.model.dao;

import gapp.model.GappApplication;

import java.util.List;

public interface GappAccountingDao {

	List<GappApplication> getGappAccounting();
}
