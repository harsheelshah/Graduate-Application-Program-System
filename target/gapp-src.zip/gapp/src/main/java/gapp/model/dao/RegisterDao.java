package gapp.model.dao;

import gapp.model.GappUsers;

public interface RegisterDao {
	
	GappUsers saveUsers(GappUsers users);

}
