
    drop table gapp_users_gapp_user_additional ;

    drop table gapp_users_gapp_users_type ;

    drop table gapp_academic_records ;
	
	drop table gapp_applications ;

	drop table gapp_program ;
	
	drop table gapp_department ;
	
    drop table gapp_additional ;

	drop table gapp_application_status ;

	drop table gapp_file ;

	drop table gapp_list_status ;

	drop table gapp_status ;

	drop table gapp_user_additional ;

	drop table gapp_users ;

	drop table gapp_users_type ;
    
	drop sequence hibernate_sequence;